# বাংলা ব্যাকরণ বিশ্লেষক

HSC বাংলা ব্যাকরণ বিশ্লেষক — NCTB ও বাংলা একাডেমি অনুসারে, Web Search powered।

## Setup করার নিয়ম

### ১. Dependencies install করো
```bash
npm install
```

### ২. Environment variable সেট করো
`.env.local` নামে একটি file বানাও এবং লেখো:
```
ANTHROPIC_API_KEY=your_api_key_here
```
API key পাবে: https://console.anthropic.com

### ৩. Local এ run করো
```bash
npm run dev
```
তারপর browser এ যাও: http://localhost:3000

---

## Vercel এ Deploy করার নিয়ম

### ধাপ ১ — GitHub এ upload করো
1. [github.com](https://github.com) এ নতুন repository বানাও
2. এই folder এর সব file সেই repository তে push করো:
```bash
git init
git add .
git commit -m "initial commit"
git remote add origin https://github.com/তোমার-username/bangla-grammar.git
git push -u origin main
```

### ধাপ ২ — Vercel এ deploy করো
1. [vercel.com](https://vercel.com) এ যাও এবং GitHub দিয়ে login করো
2. "New Project" ক্লিক করো
3. তোমার `bangla-grammar` repository select করো
4. **Environment Variables** section এ যোগ করো:
   - Key: `ANTHROPIC_API_KEY`
   - Value: তোমার API key
5. "Deploy" ক্লিক করো

কয়েক মিনিটের মধ্যে তোমার website live হয়ে যাবে! 🎉

---

## File Structure
```
bangla-grammar/
├── src/
│   └── app/
│       ├── api/
│       │   └── analyze/
│       │       └── route.js      ← Server: Anthropic API call
│       ├── globals.css
│       ├── layout.js
│       ├── page.js               ← Main UI
│       └── page.module.css
├── next.config.js
├── package.json
└── README.md
```
